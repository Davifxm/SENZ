import 'package:flutter/material.dart';

class ExpliquePage extends StatefulWidget {
  const ExpliquePage({super.key});
  @override
  State<ExpliquePage> createState() => _ExpliquePageState();
}

class _ExpliquePageState extends State<ExpliquePage> {
  final _controller = PageController();
  int _index = 0;

  static const _blue = Color(0xFF1B425A);
  static const _dotInactive = Color(0xFFCCD3DA);

  final _pages = const [
    _ScreenData(
      title: 'Sinta. SENZ percebe.',
      img: 'assets/blu.jpeg',
      desc:
          'Ela capta sinais do seu corpo, como batimentos e suor e entende quando algo muda nas suas emoções.',
    ),
    _ScreenData(
      title: 'Ela fala com você. de verdade.',
      img: 'assets/ex2.jpeg',
      desc:
          'Quando você está sobrecarregado, a pulseira envia mensagens de apoio, exercícios de respiração ou meditação direto no app, no seu fone ou por vibrações sutis em sua pulseira.',
    ),
    _ScreenData(
      title: 'Ajuda contínua, silenciosa e universal',
      img: 'assets/ex3.jpeg',
      desc:
          'Funciona 24h por dia, mesmo em silêncio. Os dados ajudam você e até sistemas de saúde a prevenirem crises antes que virem emergências.',
    ),
    _ScreenData(
      title: 'Bem-vindo ao SENZ!',
      img: 'assets/logo.png',
      desc: 'Vamos começar o seu bem-estar emocional.',
      isFinal: true,
    ),
  ];

  void _goTo(int i) {
    _controller.animateToPage(i,
        duration: const Duration(milliseconds: 350), curve: Curves.easeInOut);
  }

  void _next() {
    if (_index < _pages.length - 1) _goTo(_index + 1);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 900;
    final cardMaxW = isWide ? 760.0 : 560.0;
    final cardMaxH = isWide ? 560.0 : 620.0;

    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: cardMaxW, maxHeight: cardMaxH),
          child: Container(
            margin: const EdgeInsets.all(24),
            padding: const EdgeInsets.fromLTRB(32, 28, 32, 36),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Stack(
              children: [
                Column(
                  children: [
                    Expanded(
                      child: PageView.builder(
                        controller: _controller,
                        physics: const BouncingScrollPhysics(),
                        itemCount: _pages.length,
                        onPageChanged: (i) => setState(() => _index = i),
                        itemBuilder: (_, i) =>
                            _OnboardScreen(data: _pages[i], titleColor: _blue),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(_pages.length, (i) {
                        final active = i == _index;
                        return GestureDetector(
                          onTap: () => _goTo(i),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            margin: const EdgeInsets.symmetric(horizontal: 6),
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              color: active ? _blue : _dotInactive,
                              shape: BoxShape.circle,
                            ),
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 6),
                  ],
                ),
                if (_index < _pages.length - 1)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: _blue,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 18, vertical: 12),
                        shape: const StadiumBorder(),
                        elevation: 1,
                        textStyle: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      onPressed: _next,
                      child: const Text('Próximo'),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _OnboardScreen extends StatelessWidget {
  const _OnboardScreen({required this.data, required this.titleColor});
  final _ScreenData data;
  final Color titleColor;

  @override
  Widget build(BuildContext context) {
    final isDesktop = MediaQuery.of(context).size.width >= 900;

    final titleStyle = TextStyle(
      color: titleColor,
      fontWeight: FontWeight.w800,
      fontSize: isDesktop ? 28 : 24,
      height: 1.2,
    );
    final descStyle = TextStyle(
      color: const Color(0xFF2F3F4A),
      fontSize: isDesktop ? 15.5 : 14.5,
      height: 1.45,
    );

    final imgMaxWidth = isDesktop ? 360.0 : 320.0;
    final imgMaxHeight = isDesktop ? 300.0 : 260.0;

    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(top: isDesktop ? 8 : 4),
          child:
              Text(data.title, textAlign: TextAlign.center, style: titleStyle),
        ),
        ConstrainedBox(
          constraints:
              BoxConstraints(maxWidth: imgMaxWidth, maxHeight: imgMaxHeight),
          child: Padding(
            padding: EdgeInsets.only(top: isDesktop ? 18 : 14),
            child: Image.asset(data.img, fit: BoxFit.contain),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(top: isDesktop ? 16 : 14),
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: isDesktop ? 520 : 440),
            child:
                Text(data.desc, textAlign: TextAlign.center, style: descStyle),
          ),
        ),
        if (data.isFinal) ...[
          SizedBox(height: isDesktop ? 22 : 18),
          SizedBox(
            width: isDesktop ? 520 : double.infinity,
            child: Column(
              children: [
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: titleColor,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                          vertical: 14, horizontal: 18),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      textStyle: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    onPressed: () => Navigator.pushNamed(context, '/login'),
                    child: const Text('Já possuo uma conta'),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: titleColor,
                      side: BorderSide(color: titleColor, width: 2),
                      padding: const EdgeInsets.symmetric(
                          vertical: 14, horizontal: 18),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      textStyle: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    onPressed: () => Navigator.pushNamed(context, '/cadastro'),
                    child: const Text('Quero me cadastrar'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

class _ScreenData {
  final String title;
  final String img;
  final String desc;
  final bool isFinal;
  const _ScreenData({
    required this.title,
    required this.img,
    required this.desc,
    this.isFinal = false,
  });
}
