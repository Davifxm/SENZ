import 'package:flutter/material.dart';
import 'package:Senz/views/splash.dart';
import 'package:Senz/views/explique.dart';
import 'package:Senz/views/termouso.dart';

void main() => runApp(const SenzApp());

class SenzApp extends StatelessWidget {
  const SenzApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Explicações SENZ',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.white,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1B425A)),
      ),
      // Splash é a tela inicial
      home: const SplashPage(),

      routes: {
        '/explique': (_) => const ExpliquePage(), // onboarding
        '/login': (_) => const LoginPage(),
        '/cadastro': (_) => const CadastroPage(),
      },
    );
  }
}

/// Placeholders para as rotas (substitua depois)
class LoginPage extends StatelessWidget {
  const LoginPage({super.key});
  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF1B425A);
    return Scaffold(
      appBar: AppBar(
          title: const Text('Login'),
          foregroundColor: Colors.white,
          backgroundColor: blue),
      body: const Center(
          child: Text('Tela Login', style: TextStyle(fontSize: 18))),
    );
  }
}

class CadastroPage extends StatelessWidget {
  const CadastroPage({super.key});
  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF1B425A);
    return Scaffold(
      appBar: AppBar(
          title: const Text('Cadastro'),
          foregroundColor: Colors.white,
          backgroundColor: blue),
      body: const Center(
          child: Text('Tela Cadastro', style: TextStyle(fontSize: 18))),
    );
  }
}
