import 'dart:async';
import 'package:flutter/material.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _opacity;

  @override
  void initState() {
    super.initState();

    // animação de 1s para o fade-out
    _controller =
        AnimationController(vsync: this, duration: const Duration(seconds: 1));
    _opacity = Tween(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    // espera 3s, faz fade 1s, navega para /explique
    Timer(const Duration(seconds: 3), () async {
      await _controller.forward();
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/explique');
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  double _responsiveLogo(double w) {
    // ~35vw com min/max aproximados
    final target = w * 0.35;
    if (target < 120) return 120;
    if (target > 280) return 280;
    return target;
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;

    return AnimatedBuilder(
      animation: _opacity,
      builder: (_, child) => Opacity(opacity: _opacity.value, child: child),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset('assets/logo.png',
                  width: _responsiveLogo(w), fit: BoxFit.contain),
              const SizedBox(height: 8),
              const Text(
                'senz',
                style: TextStyle(
                  color: Color(0xFF0C326C),
                  fontWeight: FontWeight.w700,
                  fontSize: 28,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
