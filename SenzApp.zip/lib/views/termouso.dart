import 'package:flutter/material.dart';

class TermosDeUsoPage extends StatelessWidget {
  const TermosDeUsoPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Termos de Uso'),
        backgroundColor: const Color(0xFF0C326C),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: Text(
                'Termos de Uso',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Bem-vindo ao aplicativo e dispositivo Senz, oferecido por Senz. Estes Termos de Uso regulam o uso de nossos serviços e dispositivos pelos usuários finais.',
              style: TextStyle(fontSize: 16, height: 1.8),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),

            // 1. Aceitação dos Termos
            const Text(
              '1. Aceitação dos Termos',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Ao utilizar o app e conectar sua pulseira, você concorda integralmente com estes Termos de Uso. Caso não concorde, não utilize o serviço.',
              style: TextStyle(fontSize: 16, height: 1.8),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),

            // 2. Criação e Uso de Conta
            const Text(
              '2. Criação e Uso de Conta',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Para acessar determinadas funcionalidades, o usuário deve criar uma conta, fornecendo informações verdadeiras, completas e atualizadas.',
              style: TextStyle(fontSize: 16, height: 1.8),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),

            // 3. Funcionalidade do Dispositivo e Aplicativo
            const Text(
              '3. Funcionalidade do Dispositivo e Aplicativo',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Nosso sistema coleta dados como batimentos cardíacos e estado físico-emocional. A pulseira transmite dados ao app, que utiliza IA para oferecer orientações de bem-estar. Este serviço tem caráter informativo e não substitui orientações médicas.',
              style: TextStyle(fontSize: 16, height: 1.8),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),

            // 4. Responsabilidades do Usuário
            const Text(
              '4. Responsabilidades do Usuário',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Padding(
              padding: EdgeInsets.only(left: 8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('• Não utilizar o app para fins ilegais.',
                      style: TextStyle(fontSize: 16, height: 1.8)),
                  Text('• Não tentar acessar áreas restritas sem autorização.',
                      style: TextStyle(fontSize: 16, height: 1.8)),
                  Text('• Manter seus dados de login seguros e confidenciais.',
                      style: TextStyle(fontSize: 16, height: 1.8)),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // 5. Propriedade Intelectual
            const Text(
              '5. Propriedade Intelectual',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Todo o conteúdo do aplicativo, incluindo marca, código-fonte, design e funcionalidades, pertence à [Nome da Empresa] e é protegido por leis de propriedade intelectual.',
              style: TextStyle(fontSize: 16, height: 1.8),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),

            // 6. Isenção de Garantias
            const Text(
              '6. Isenção de Garantias',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Não garantimos que o serviço será ininterrupto ou livre de erros. O uso é por conta e risco do usuário. As informações geradas são sugestões baseadas em padrões de IA, não substituindo profissionais de saúde.',
              style: TextStyle(fontSize: 16, height: 1.8),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),

            // 7. Cancelamento e Encerramento de Conta
            const Text(
              '7. Cancelamento e Encerramento de Conta',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'O usuário pode encerrar sua conta a qualquer momento. Reservamo-nos o direito de suspender ou encerrar contas que violem os termos aqui estabelecidos.',
              style: TextStyle(fontSize: 16, height: 1.8),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),

            // 8. Alterações
            const Text(
              '8. Alterações',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Estes termos podem ser atualizados periodicamente. Você será notificado em caso de mudanças significativas.',
              style: TextStyle(fontSize: 16, height: 1.8),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),

            // 9. Contato
            const Text(
              '9. Contato',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Para dúvidas, sugestões ou solicitações: contato@empresa.com',
              style: TextStyle(fontSize: 16, height: 1.8),
            ),

            const SizedBox(height: 40),

            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(
                      context); // Volta para a tela anterior (Cadastro)
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF444444),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4)),
                ),
                child: const Text(
                  'Voltar',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
