document.addEventListener('DOMContentLoaded', () => {
  const radios = document.querySelectorAll('input[type="radio"]');

  radios.forEach(radio => {
    radio.addEventListener('change', () => {
      radios.forEach(r => {
        const box = r.nextElementSibling;
        if (box) {
          box.classList.remove('active');
        }
      });

      const selectedBox = radio.nextElementSibling;
      if (selectedBox) {
        selectedBox.classList.add('active');
      }
    });
  });
});
